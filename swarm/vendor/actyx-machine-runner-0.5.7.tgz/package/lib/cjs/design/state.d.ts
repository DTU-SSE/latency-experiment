import { ActyxEvent } from '@actyx/sdk';
import * as utils from '../utils/type-utils.js';
import { CommandDefiner, CommandDefinerMap } from './command.js';
import { Contained, MachineEvent } from './event.js';
import { Logger } from '../utils/logger.js';
export * from './command.js';
export * from './event.js';
export type CommandContext<Self, EmittedEventFactories extends MachineEvent.Factory.Any> = {
    self: Self;
    /**
     * Attach tags to MachineEvents associated to this command
     * @param tags the tags that will be attached to the MachineEvents
     */
    withTags: <InputPayload extends MachineEvent.Payload.Of<EmittedEventFactories>>(tags: string[], payload: InputPayload) => Contained.ContainedPayload<InputPayload>;
};
/**
 * @private not intended for use outside of actyx packages.
 */
export type StateRaw<Name extends string, Payload> = {
    type: Name;
    payload: Payload;
};
/**
 * @private not intended for use outside of actyx packages.
 */
export declare namespace StateRaw {
    type Any = StateRaw<string, unknown>;
}
export type CommandContextBT<Self, EmittedEventFactories extends MachineEvent.Factory.Any> = {
    self: Self;
    jbLast: Map<string, string>;
    logger?: Logger;
    /**
     * Attach tags to MachineEvents associated to this command
     * @param tags the tags that will be attached to the MachineEvents
     */
    withTags: <InputPayload extends MachineEvent.Payload.Of<EmittedEventFactories>>(tags: string[], payload: InputPayload) => Contained.ContainedPayload<InputPayload>;
};
/**
 * @private not intended for use outside of actyx packages.
 */
export type StateRawBT<Name extends string, Payload> = {
    type: Name;
    payload: Payload;
    jbLast: Map<string, string>;
    logger?: Logger;
};
/**
 * @private not intended for use outside of actyx packages.
 */
export declare namespace StateRawBT {
    type Any = StateRawBT<string, unknown>;
}
export type ReactionHandler<EventChain extends ActyxEvent<MachineEvent.Any>[], Context, RetVal> = (context: Context, ...events: EventChain) => RetVal;
export type Reaction<Context> = {
    eventChainTrigger: Readonly<MachineEvent.Factory.Any[]>;
    next: StateFactory.Any;
    handler: ReactionHandler<ActyxEvent<MachineEvent.Any>[], Context, unknown>;
};
export type ReactionContext<Self> = {
    self: Self;
};
export type ReactionMapPerMechanism<Payload> = Map<string, Reaction<ReactionContext<Payload>>>;
export type ReactionMap = {
    get: <Payload>(mechanism: StateMechanism<any, any, any, any, Payload, any>) => ReactionMapPerMechanism<Payload>;
    getAll: () => Map<StateMechanism.Any, ReactionMapPerMechanism<any>>;
    add: (now: StateMechanism.Any, triggers: Readonly<MachineEvent.Factory.Any[]>, next: StateFactory.Any, reaction: ReactionHandler<ActyxEvent<MachineEvent.Any>[], ReactionContext<any>, unknown>) => void;
};
export declare namespace ReactionMap {
    const make: () => ReactionMap;
}
export type MachineProtocol<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any> = {
    readonly swarmName: SwarmProtocolName;
    readonly name: MachineName;
    readonly registeredEvents: MachineEventFactories[];
    readonly reactionMap: ReactionMap;
    readonly commands: {
        ofState: string;
        commandName: string;
        events: string[];
    }[];
    readonly states: {
        readonly registeredNames: Set<string>;
        readonly allFactories: Set<StateFactory.Any>;
    };
};
export declare namespace MachineProtocol {
    type Any = MachineProtocol<string, string, any>;
}
export type StateMechanism<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<object, unknown[], Contained.ContainedEvent<MachineEvent.Any>[]>> = {
    readonly protocol: MachineProtocol<SwarmProtocolName, MachineName, MachineEventFactories>;
    readonly name: StateName;
    readonly commands: Commands;
    /**
     * Attach a command to a state. The attached commands are available when a
     * MachineRunner is in that particular state. Note that a command will not
     * automatically trigger a state change. A reaction must be defined to
     * properly trigger a state change.
     * @see StateFactory.react on how to define a reaction
     * @example
     * const HangarControlIdle = protocol
     *   .designState("HangarControlIdle")
     *   .withPayload<{
     *     dockingRequests: { shipId: string, at: Date }[]
     *   }>()
     *   .command('acceptDockingRequest', [DockingRequestAccepted], (context, shipId: string) => [
     *     DockingRequestAccepted.make({
     *       shipId
     *     })
     *   ])
     *   .finish()
     * // When a machine is in a certain state, the commands are available at runtime.
     * // TypeScript type hints for the command's parameters are available
     * const state = machine.get(); // machine is an instance of MachineRunner
     * if (state.is(HangarControlIdle)) {
     *   state.cast().commands()?.acceptDockingRequest("someShipId");
     * }
     */
    readonly command: <CommandName extends string, EmittedEventFactories extends utils.ReadonlyNonZeroTuple<MachineEventFactories>, CommandArgs extends unknown[]>(name: CommandName extends `_${string}` ? never : CommandName, events: EmittedEventFactories, handler: CommandDefiner<CommandContext<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>> | CommandContextBT<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>>, CommandArgs, MachineEvent.Factory.MapToPayloadOrContainedPayload<EmittedEventFactories>>) => StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands & {
        [key in CommandName]: CommandDefiner<CommandContext<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>> | CommandContextBT<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>>, CommandArgs, MachineEvent.Factory.MapToPayloadOrContainedPayload<EmittedEventFactories>>;
    }>;
    readonly commandFromList: <CommandName extends string, EmittedEventFactories extends utils.ReadonlyNonZeroTuple<MachineEventFactories>, CommandArgs extends unknown[]>(cmds: [
        (CommandName extends `_${string}` ? never : CommandName),
        (EmittedEventFactories),
        (CommandDefiner<CommandContext<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>> | CommandContextBT<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>>, CommandArgs, MachineEvent.Factory.MapToPayloadOrContainedPayload<EmittedEventFactories>>)
    ][]) => StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands & {
        [key in CommandName]: CommandDefiner<CommandContext<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>> | CommandContextBT<StatePayload, MachineEvent.Factory.Reduce<EmittedEventFactories>>, CommandArgs, MachineEvent.Factory.MapToPayloadOrContainedPayload<EmittedEventFactories>>;
    }>;
    readonly commandDefinitions: Map<string, CommandDefiner<CommandContext<StatePayload, MachineEvent.Factory.Reduce<any>> | CommandContextBT<StatePayload, MachineEvent.Factory.Reduce<any>>, unknown[], MachineEvent.Factory.MapToPayloadOrContainedPayload<any>>>;
    /**
     * Finalize state design process.
     * @returns a StateFactory
     */
    readonly finish: () => StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
};
export declare namespace StateMechanism {
    type Any = StateMechanism<string, string, MachineEvent.Factory.Any, string, any, any>;
    const make: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(protocol: MachineProtocol<SwarmProtocolName, MachineName, MachineEventFactories>, stateName: StateName, props?: {
        commands?: Commands;
        commandDataForAnalytics: {
            commandName: string;
            events: string[];
        }[];
        commandDefinitions?: Map<string, any>;
    }) => StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
}
/**
 * A reference to a state. A StateFactory is used for determining if a snapshot
 * of a state is of a particular type and as a notation for the "next-state" of
 * a reaction.
 */
export type StateFactory<SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = {
    /**
     * Helper to create a state payload to match the constraint of the state type.
     * @see react for more example.
     */
    make: (payload: StatePayload) => StatePayload;
    symbol: () => symbol;
    readonly mechanism: StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
    /**
     * Add a reaction to a set of incoming events for a particular state. A
     * reaction is a computation that MAY result in a state transition or a
     * self-mutation.
     * @example
     * HangarControlIdle
     *   .react([IncomingDockingRequest], HangarControlIdle, (context, request) => {
     *     context.self.dockingRequests.push({ shipId: request.shipId, at: new Date() })
     *   })
     * @example
     * HangarControlIdle
     *   .react(
     *     [DockingRequestAccepted],
     *     HangarControlDocking,
     *     (context, accepted) => HangarControlDocking.make({
     *       shipId: accepted.shipId
     *     })
     *   )
     */
    react: <EventFactoriesChain extends utils.ReadonlyNonZeroTuple<MachineEventFactories>, NextPayload>(eventChainTrigger: EventFactoriesChain, nextFactory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, string, NextPayload, any>, handler: ReactionHandler<MachineEvent.Factory.MapToActyxEvent<EventFactoriesChain>, ReactionContext<StatePayload>, NextPayload>) => void;
    reactIntoSelf: <EventFactoriesChain extends utils.ReadonlyNonZeroTuple<MachineEventFactories>>(eventChainTrigger: EventFactoriesChain, handler: ReactionHandler<MachineEvent.Factory.MapToActyxEvent<EventFactoriesChain>, ReactionContext<StatePayload>, void>) => void;
};
export declare namespace StateFactory {
    type Minim = StateFactory<any, any, MachineEvent.Factory.Any, string, any[], CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>;
    type Any = StateFactory<any, any, any, any, any, any>;
    type PayloadOf<T extends StateFactory.Any> = T extends StateFactory<any, any, any, any, infer Payload, any> ? Payload : never;
    type ReduceIntoPayload<F extends Readonly<StateFactory.Any[]>, UNION extends unknown = never> = F extends Readonly<[
        StateFactory<any, any, any, any, infer Payload, any>,
        ...infer Rest extends Readonly<StateFactory.Any[]>
    ]> ? ReduceIntoPayload<Rest, UNION | Payload> : UNION;
    const fromMechanism: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(mechanism: StateMechanism<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>) => StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>;
}
