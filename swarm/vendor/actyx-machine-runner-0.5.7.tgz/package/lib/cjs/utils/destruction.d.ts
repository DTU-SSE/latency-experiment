/**
 * Utility to help centralize destruction-related mechanisms such as marking an
 * object as destroyed, invoking previously registered cleanup functions, and
 * guarding cleanup to be invoked once.
 */
export type Destruction = ReturnType<typeof Destruction['make']>;
export declare namespace Destruction {
    const make: () => {
        addDestroyHook: (fn: () => void) => void;
        removeDestroyHook: (fn: () => void) => void;
        isDestroyed: () => boolean;
        destroy: () => void;
    };
}
/**
 * Utility to collect a set of functions that will be called when the "clean"
 * method is called.
 */
export type Cleanup = ReturnType<typeof Cleanup['make']>;
export declare namespace Cleanup {
    const make: () => {
        add: (fn: () => void) => void;
        remove: (fn: () => void) => void;
        clean: () => void;
    };
}
