export declare const NOP: <T extends unknown[]>(..._: T) => void;
