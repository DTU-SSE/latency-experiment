import * as pino from 'pino';
import { SerializableObject } from './type-utils.js';
export type Direction = "Received" | "Emitted";
export type Logger = {
    readonly outputFile: string;
    readonly logRef: pino.Logger<never, boolean>;
    log: (data: SerializableObject) => void;
    logEvent: (event: SerializableObject, direction: Direction) => void;
};
export declare namespace Logger {
    const make: (outputFile: string) => Logger;
}
