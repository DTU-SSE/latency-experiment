export declare const jsonDeepCopy: <T>(item: T) => T;
export declare function deepCopy<T>(source: T): T;
