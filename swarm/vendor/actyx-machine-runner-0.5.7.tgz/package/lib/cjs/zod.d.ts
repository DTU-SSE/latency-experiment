export declare const importZod: () => {
    zod: typeof import("zod");
    zodError: typeof import("zod-validation-error");
};
