import { MachineEvent } from '../index.js';
import { CommandDefinerMap, Contained, StateFactory } from '../design/state.js';
type Options = {
    disableCommands?: boolean;
    capturedEvents?: unknown[];
};
export declare const createMockStateOpaque: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>, payload: StatePayload, options?: Options) => import("../index.js").StateOpaque<SwarmProtocolName, MachineName, string, unknown, object>;
export declare const createMockState: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(factory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, StateName, StatePayload, Commands>, payload: StatePayload, options?: Options) => import("../index.js").State<StateName, StatePayload, Commands>;
export {};
