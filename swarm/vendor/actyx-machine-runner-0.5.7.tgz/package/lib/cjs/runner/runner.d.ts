import { Actyx, CancelSubscription, EventsOrTimetravel, Metadata, OnCompleteOrErr, TaggedEvent, Tags } from '@actyx/sdk';
import { MachineEvent, StateRaw, StateFactory, CommandDefinerMap, ToCommandSignatureMap, Contained } from '../design/state.js';
import { Destruction } from '../utils/destruction.js';
import { RunnerInternals, StateAndFactory } from './runner-internals.js';
import { MachineEmitter, MachineEmitterEventMap } from './runner-utils.js';
import { Machine, SwarmProtocol, AdaptedMachine } from '../design/protocol.js';
import { MachineRunnerFailure } from '../errors.js';
import { Logger } from '../utils/logger.js';
/**
 * Contains and manages the state of a machine by subscribing and publishing
 * events via an active connection to Actyx. A MachineRunner manages state
 * reactions and transitions when incoming events from Actyx match one of the
 * reactions of the MachineRunner's state as defined by the user via the machine
 * protocol.
 *
 * MachineRunner can be used as an async-iterator. However, if used as an
 * async-iterator, it will be destroyed when a 'break' occurs on the loop.
 * @example
 * const state = machine.get();
 *
 * @example
 * for await (const state of machine) {
 *   break; // this destroys `machine`
 * }
 * machine.isDestroyed() // returns true
 */
export type MachineRunner<SwarmProtocolName extends string, MachineName extends string, StateUnion extends unknown = unknown> = {
    id: symbol;
    events: MachineEmitter<SwarmProtocolName, MachineName, StateUnion>;
    /**
     * Disconnect from Actyx and disable future reactions and commands.
     */
    destroy: () => unknown;
    /**
     * @returns whether this MachineRunner is destroyed/disconnected from Actyx.
     */
    isDestroyed: () => boolean;
    /**
     * @returns a snapshot of the MachineRunner's current state in the form of
     * StateOpaque.
     * @returns null if the MachineRunner has not processed all incoming events
     * for the first time.
     */
    get: () => StateOpaque<SwarmProtocolName, MachineName, string, StateUnion> | null;
    /**
     * @returns a snapshot of the MachineRunner's initial state in the form of
     * StateOpaque.
     */
    initial: () => StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>;
    /**
     * @returns a copy of the MachineRunner referring to its parent's state that
     * does not destroy the parent when it is destroyed.
     * @example
     * for await (const state of machine.noAutoDestroy()) {
     *   break; // this break does not destroy `machine`
     * }
     * machine.isDestroyed() // returns false
     */
    noAutoDestroy: () => MachineRunnerIterableIterator<SwarmProtocolName, MachineName, StateUnion>;
    /**
     * Add type refinement to the state payload produced by the machine-runner
     *
     * @param stateFactories - All state factories produced by the
     * MachineProtocol. All state factories must be included, otherwise (i.e.
     * passing only some state factories) will result in an exception being
     * thrown.
     * @return a reference the machine-runner instance with added type refinement
     *
     * @example
     * const machineRunner = createMachineRunner(actyx, where, StateA, undefined)
     *  .refineStateType([StateA, StateB, StateC] as const);
     *
     * const stateSnapshot = machineRunner.get();
     * if (!stateSnapshot) return
     *
     * const payload = stateSnapshot.payload; // union of payloads of StateA, StateB, and StateC
     */
    refineStateType: <Factories extends Readonly<StateFactory<SwarmProtocolName, MachineName, any, any, any, any>[]>>(_: Factories) => MachineRunner<SwarmProtocolName, MachineName, StateFactory.ReduceIntoPayload<Factories>>;
} & MachineRunnerIterableIterator<SwarmProtocolName, MachineName, StateUnion>;
export declare namespace MachineRunner {
    /**
     * The widest type of MachineRunner. Any other MachineRunner extends this type
     */
    type Any = MachineRunner<string, string, any>;
    type EventsOf<T extends MachineRunner.Any> = T extends Machine<any, any, infer MachineEventFactories> ? MachineEvent.Of<MachineEventFactories> : never;
    /**
     * Extract MachineRunner event emitter map type from a MachineRunner
     * @example
     * const machineRunner = createMachineRunner(actyx, where, Passenger.Initial, void 0);
     *
     * type EventMap = MachineRunner.EventMapOf<typeof machineRunner>
     * type OnChange = EventMap['change']
     *
     * const onChange: EventMap['change'] = () =>
     *  console.log(label, 'state after caughtUp', utils.deepCopy(machine.get()))
     * machine.events.on('change', onChange)
     *
     * // later
     * machine.events.off('change', onChange)
     */
    type EventMapOf<M extends MachineRunner<any, any, any>> = M extends MachineRunner<infer S, infer N, infer SU> ? MachineEmitterEventMap<S, N, SU> : never;
    /**
     * Extract MachineRunner type from SwarmProtocol or Machine
     * @example
     * const HangarBay = SwarmProtocol.make(
     *   'HangarBay',
     *   [HangarDoorTransitioning, HangarDoorClosed, HangarDoorOpen]
     * )
     * const Door = HangarBay.makeMachine('door')
     * const Initial = Door.designEmpty().finish()
     *
     * // refers to any MachineRunner derived from HangarBay protocol
     * type ThisMachineRunner = MachineRunner.Of<typeof HangarBay>
     *
     * // refers to any MachineRunner derived from HangarBay protocol and Door machine
     * type ThisMachineRunner = MachineRunner.Of<typeof Door>
     */
    type Of<S extends SwarmProtocol<any, any> | Machine<any, any, any>> = S extends SwarmProtocol<infer S, any> ? MachineRunner<S, string, unknown> : S extends Machine<infer S, infer N, any> ? MachineRunner<S, N, unknown> : never;
    const mergeExtraTags: <E>(tags: Tags<E>, extraData: Contained.ExtraData | null) => Tags<E>;
    const tagContainedEvent: <E extends MachineEvent.Any>(tags: Tags<E>, containedEvent: Contained.ContainedEvent<E>) => TaggedEvent;
}
export type SubscribeFn<E extends MachineEvent.Any> = (callback: (data: EventsOrTimetravel<E>) => Promise<void>, onCompleteOrErr?: OnCompleteOrErr) => CancelSubscription;
export type PersistFn<E extends MachineEvent.Any> = (events: Contained.ContainedEvent<E>[]) => Promise<Metadata[]>;
type PublishFn = (events: TaggedEvent[]) => Promise<Metadata[]>;
/**
 * @param sdk - An instance of Actyx.
 * @param tags - List of tags to be subscribed. These tags will also be added to
 * events published to Actyx.
 * @param initialFactory - initial state factory of the machine.
 * @param initialPayload - initial state payload of the machine.
 * @returns a MachineRunner instance.
 */
export declare const createMachineRunner: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, Payload, MachineEvents extends MachineEvent.Any = MachineEvent.Of<MachineEventFactories>, StateUnion extends unknown = unknown>(sdk: Actyx, tags: Tags<MachineEvents>, initialFactory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, Payload, any>, initialPayload: Payload) => MachineRunner<SwarmProtocolName, MachineName, StateUnion>;
/**
 * Construct a branch-tracking {@link MachineRunner}.
 * In a composed swarm, each machine maintains a mapping from
 * event types to [eventId](https://github.com/Actyx/Actyx/blob/master/js/sdk/src/types/various.ts#L243)s,
 * updating the map when receiving *branching*, *joining*, or *looping* events.
 * When a machine emits an event of some type, it attaches the
 * eventId associated with the type by the mapping to the event.
 *
 * A branch-tracking MachineRunner maintains the event-type-to-eventId mapping
 * and ignores events not pointing to the expected eventIds.
 *
 * @param sdk - An instance of Actyx.
 * @param tags - List of tags to be subscribed. These tags will also be added to
 * events published to Actyx.
 * @param initialFactory - initial state factory of the machine.
 * @param initialPayload - initial state payload of the machine.
 * @param adaptedMachine - the {@link AdaptedMachine} to run.
 * @returns - a MachineRunner instance.
 */
export declare const createMachineRunnerBT: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, Payload, MachineEvents extends MachineEvent.Any = MachineEvent.Of<MachineEventFactories>, StateUnion extends unknown = unknown>(sdk: Actyx, tags: Tags<MachineEvents>, initialFactory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, Payload, any>, initialPayload: any, adaptedMachine: AdaptedMachine<SwarmProtocolName, MachineName, MachineEventFactories>, logger?: Logger) => MachineRunner<SwarmProtocolName, MachineName, StateUnion>;
export declare const createMachineRunnerInternal: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, Payload, MachineEvents extends MachineEvent.Any = MachineEvent.Of<MachineEventFactories>, StateUnion extends unknown = unknown>(subscribe: SubscribeFn<MachineEvents>, publish: PublishFn, tags: Tags, initialFactory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, Payload, any>, initialPayload: Payload) => MachineRunner<SwarmProtocolName, MachineName, StateUnion>;
export declare const createMachineRunnerInternalBT: <SwarmProtocolName extends string, MachineName extends string, MachineEventFactories extends MachineEvent.Factory.Any, Payload, MachineEvents extends MachineEvent.Any = MachineEvent.Of<MachineEventFactories>, StateUnion extends unknown = unknown>(subscribe: SubscribeFn<MachineEvents>, publish: PublishFn, tags: Tags, initialFactory: StateFactory<SwarmProtocolName, MachineName, MachineEventFactories, any, Payload, any>, initialPayload: Payload, succeedingNonBranchingJoining: Record<string, string[]>, specialEvents: Set<string>, logger?: Logger) => MachineRunner<SwarmProtocolName, MachineName, StateUnion>;
export type MachineRunnerIterableIterator<SwarmProtocolName extends string, MachineName extends string, StateUnion extends unknown> = AsyncIterable<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>> & AsyncIterableIterator<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>> & AsyncIterator<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>, null> & {
    /**
     * @deprecated use `peekNext` instead
     *
     * The returned promise resolves when the machine-runner async iterator has received more events and computed the next ready-state.
     * Ready state is invalidated by calls to `next` method which returns the same promise.
     *
     * Unlike `next`, it does not invalidate current ready-state.
     *
     * Unilke `get`, it waits for a ready-state instead of returning the immediate state of the machine runner, which is nullable
     *
     * @returns Promise<{ done: false, value: StateOpaque } | { done: true, value: null }>
     */
    peek: () => Promise<IteratorResult<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>, null>>;
    /**
     * The returned promise resolves when the machine-runner async iterator has received more events and computed the next ready-state.
     * Ready state is invalidated by calls to `next` method which returns the same promise.
     *
     * Unlike `next`, it does not invalidate current ready-state.
     *
     * Unilke `get`, it waits for a ready-state instead of returning the immediate state of the machine runner, which is nullable
     *
     * @returns Promise<{ done: false, value: StateOpaque } | { done: true, value: null }>
     */
    peekNext: () => Promise<IteratorResult<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>, null>>;
    /**
     * Returns a promise that, when caught up, resolves immediately. If the
     * machine is destroyed, returns the `done` variant of the iterator result.
     * Otherwise behaves similarly to `peekNext`.
     *
     * @returns Promise<{ done: false, value: StateOpaque } | { done: true, value: null }>
     */
    actual: () => Promise<IteratorResult<StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>, null>>;
    /**
     * Destroys current Iterator. If it belongs to a `noAutoDestroy` variant, it
     * only destroys the copy and not the original one.
     */
    destroy: () => void;
};
/**
 * Object to help "awaiting" next value.
 */
export type NextValueAwaiter<S extends StateOpaque<any, any, any>> = ReturnType<typeof NextValueAwaiter.make<S>>;
declare namespace NextValueAwaiter {
    const make: <S extends StateOpaque<any, any, any>>({ topLevelDestruction, currentLevelDestruction, failure, cloneFrom, }: {
        topLevelDestruction: Destruction;
        currentLevelDestruction: Destruction;
        failure: () => MachineRunnerFailure | null;
        cloneFrom?: {
            state: S;
        };
    }) => {
        kill: () => void;
        fail: (f: MachineRunnerFailure) => void;
        push: (state: S) => void;
        state: () => {
            state: S;
        } | undefined;
        consume: () => Promise<IteratorResult<S, null>>;
        peek: () => Promise<IteratorResult<S, null>>;
        purgeWhenMatching: (comparedState: S) => void;
    };
}
type StateOpaqueInternalAccess = {
    /**
     * Do not use internal
     */
    [ImplStateOpaque.InternalAccess]: () => StateAndFactory<any, any, any, any, any, any>;
};
/**
 * StateOpaque is an opaque snapshot of a MachineRunner state. A StateOpaque
 * does not have direct access to the state's payload or command. In order to
 * access the state's payload, a StateOpaque has to be successfully cast into a
 * particular typed State.
 */
export interface StateOpaque<SwarmProtocolName extends string, MachineName extends string, StateName extends string = string, Payload = unknown, Commands extends CommandDefinerMap<object, any, Contained.ContainedEvent<MachineEvent.Any>[]> = object> extends StateOpaqueInternalAccess, StateRaw<StateName, Payload> {
    /**
     * Checks if the StateOpaque's type equals to the StateFactory's type.
     *
     * @param ...factories - StateFactory used to narrow the StateOpaque's type.
     *
     * @return boolean that narrows the type of the StateOpaque based on the
     * supplied StateFactory.
     *
     * @example
     * const state = machine.get()
     * if (state.is(HangarControlIdle)) {
     *   // StateOpaque is narrowed inside this block
     * }
     *
     * @example
     * const state = machine.get()
     * if (state.is(HangarControlIdle, HangarControlIncomingShip)) {
     *   // StateOpaque is narrowed into HangarControlIdle or HangarControlIncomingShip
     * }
     */
    is<F extends StateFactory<SwarmProtocolName, any, any, any, any, any>[]>(...factories: F): this is StateOpaque.Of<F[any]>;
    /**
     * Attempt to cast the StateOpaque into a specific StateFactory and optionally
     * transform the value with the `then` function. Whether casting is successful
     * or not depends on whether the StateOpaque's State matches the factory
     * supplied via the first parameter.
     *
     * @param factory - A StateFactory used to cast the StateOpaque.
     *
     * @param then - an optional transformation function accepting the typed state
     * and returns an arbitrary value. This function will be executed if the
     * casting is successful.
     *
     * @return a typed State with access to payload and commands if the `then`
     * function is not supplied and the casting is successful, any value returned
     * by the `then` function if supplied and casting is successful, null if
     * casting is not successful.
     *
     * @example
     * const maybeHangarControlIdle = machine
     *   .get()?
     *   .as(HangarControlIdle)
     * if (maybeHangarControlIdle !== null) {
     *   // do something with maybeHangarControlIdle
     * }
     * @example
     * const maybeFirstDockingRequest = machine
     *  .get()?
     *  .as(HangarControlIdle, (state) => state.dockingRequests.at(0))
     */
    as<DeduceMachineName extends MachineName, StateName extends string, StatePayload extends any, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>(factory: StateFactory<SwarmProtocolName, DeduceMachineName, any, StateName, StatePayload, Commands>): State<StateName, StatePayload, Commands> | undefined;
    /**
     * Attempt to cast the StateOpaque into a specific StateFactory and optionally
     * transform the value with the `then` function. Whether casting is successful
     * or not depends on whether the StateOpaque's State matches the factory
     * supplied via the first parameter.
     *
     * @param factory - A StateFactory used to cast the StateOpaque.
     *
     * @param then - an optional transformation function accepting the typed state
     * and returns an arbitrary value. This function will be executed if the
     * casting is successful.
     *
     * @return a typed State with access to payload and commands if the `then`
     * function is not supplied and the casting is successful, any value returned
     * by the `then` function if supplied and casting is successful, null if
     * casting is not successful.
     *
     * @example
     * const maybeHangarControlIdle = machine
     *   .get()?
     *   .as(HangarControlIdle)
     * if (maybeHangarControlIdle !== null) {
     *   // do something with maybeHangarControlIdle
     * }
     * @example
     * const maybeFirstDockingRequest = machine
     *  .get()?
     *  .as(HangarControlIdle, (state) => state.dockingRequests.at(0))
     */
    as<DeduceMachineName extends MachineName, DeduceFactories extends MachineEvent.Factory.Any, StateName extends string, StatePayload extends any, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>, Then extends (arg: State<StateName, StatePayload, Commands>) => any>(factory: StateFactory<SwarmProtocolName, DeduceMachineName, DeduceFactories, StateName, StatePayload, Commands>, then: Then): ReturnType<Then> | undefined;
    /**
     * Cast into a typed State. Usable only inside a block where this
     * StateOpaque's type is narrowed.
     *
     * @return typed State with access to payload and commands.
     *
     * @example
     * const state = machine.get()
     * if (state.is(HangarControlIdle)) {
     *   const typedState = state.cast()                  // typedState is an instance of HangarControlIdle
     *   console.log(typedState.payload.dockingRequests)  // payload is accessible
     *   console.log(typedState.commands())                 // commands MAY be accessible depending on the state of the MachineRunners
     * }
     */
    cast(): State<StateName, Payload, Commands>;
    /**
     * Return true when all commands enabled in the factory are enabled in the StateOpaque. (and they have the same payload type? possible).
     *
     * @param factory - A StateFactory used to compare with the StateOpaque.
     */
    isLike<F extends StateFactory<SwarmProtocolName, any, any, any, any, any>>(factory: F): this is StateOpaque.Of<F>;
    /**
     * True if factory has a command named cmd
     *
     * @param cmd - The name of a command to look up in the StateOpaque.
     */ /**
     * Return true when the commands of its state counterpart is available; otherwise return false.
     */
    commandsAvailable(): boolean;
    /**
     * Return true when the state counterpart does not enable any commands and does not have any reactions attached; otherwise return false.
     */
    isFinal(): boolean;
}
export declare namespace StateOpaque {
    /**
     * The widest type of StateOpaque. Any other StateOpaque extends this type
     */
    type Any = StateOpaque<string, string, string, any, object>;
    /**
     * Derive StateOpaque type from a SwarmProtocol, a Machine, or a MachineRunner
     * @example
     *
     * const HangarBay = SwarmProtocol.make(
     *   'HangarBay',
     *   [HangarDoorTransitioning, HangarDoorClosed, HangarDoorOpen]
     * )
     * const Door = HangarBay.makeMachine('door')
     * const Initial = Door.designEmpty().finish()
     * const machineRunner = createMachineRunner(actyx, where, Passenger.Initial, void 0);
     *
     * // Two types below refers to any StateOpaque coming from Door machine, HangarBay protocol
     * type ThisStateOpaque1 = StateOpaque.Of<typeof machineRunner>;
     * type ThisStateOpaque2 = StateOpaque.Of<typeof Door>;
     *
     * // The type below refers to any StateOpaque coming from HangarBay protocol
     * type ThisStateOpaque3 = StateOpaque.Of<typeof HangarBay>;
     */
    type Of<M extends MachineRunner.Any | Machine.Any | SwarmProtocol<any, any> | StateFactory.Any> = M extends MachineRunner<infer S, infer N, infer SU> ? StateOpaque<S, N, string, SU> : M extends Machine<infer S, infer N, any> ? StateOpaque<S, N, string, unknown> : M extends SwarmProtocol<infer S, any> ? StateOpaque<S, any, string, unknown> : M extends StateFactory<infer S, infer N, any, infer StateName, infer Payload, infer Commands> ? StateOpaque<S, N, StateName, Payload, Commands> : never;
}
export declare namespace ImplStateOpaque {
    const isExpired: (internals: RunnerInternals.Any, stateAndFactoryForSnapshot: StateAndFactory.Any) => boolean;
    const isCommandLocked: (internals: RunnerInternals.Any) => boolean;
    const isRunnerDestroyed: (internals: RunnerInternals.Any) => boolean;
    const InternalAccess: unique symbol;
    const eq: (a: StateOpaque<any, any, any, any>, b: StateOpaque<any, any, any, any>) => boolean;
    const eqInternal: (a: StateAndFactory<any, any, any, any, any, any>, b: StateAndFactory<any, any, any, any, any, any>) => boolean;
    const make: <SwarmProtocolName extends string, MachineName extends string, StateUnion extends unknown>(internals: RunnerInternals.Any, stateAndFactoryForSnapshot: StateAndFactory<SwarmProtocolName, MachineName, any, any, any, any>) => StateOpaque<SwarmProtocolName, MachineName, string, StateUnion>;
}
/**
 * A typed snapshot of the MachineRunner's state with access to the state's
 * payload and the associated commands.
 *
 * Commands are available only if at the time the snapshot is created these
 * conditions are met: 1.) the MachineRunner has caught up with Actyx's events
 * stream, 2.) there are no events in the internal queue awaiting processing,
 * 3.) no command has been issued from this State yet.
 *
 * Commands run the associated handler defined on the state-design step and will
 * persist all the events returned by the handler into Actyx. It returns a
 * promise that is resolved when persisting is successful and rejects when
 * persisting is failed.
 */
export type State<StateName extends string, StatePayload, Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = StateRaw<StateName, StatePayload> & {
    /**
     * A dictionary containing commands previously registered during the State
     * Design process. Undefined when commands are unavailable during the time of
     * the state snapshot.
     *
     * Commands are available only if at the time the snapshot is created these
     * conditions are met: 1.) the MachineRunner has caught up with Actyx's events
     * stream, 2.) there are no events in the internal queue awaiting processing,
     * 3.) no command has been issued from this State yet
     *
     * Commands run the associated handler defined on the state-design step and
     * will persist all the events returned by the handler into Actyx. It returns
     * a promise that is resolved when persisting is successful and rejects when
     * persisting is failed.
     */
    commands: CommandsOfStateGenerator<Commands>;
};
type CommandsOfStateGenerator<Commands extends CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>> = () => ToCommandSignatureMap<Commands, any, Contained.ContainedEvent<MachineEvent.Any>[]> | undefined;
/**
 * A collection of type utilities around the State.
 */
export declare namespace State {
    type Minim = State<string, any, CommandDefinerMap<any, any, Contained.ContainedEvent<MachineEvent.Any>[]>>;
    type NameOf<T extends State.Minim> = T extends State<infer Name, any, any> ? Name : never;
    /**
     * Extract the typed state from a StateFactory.
     *
     * @example
     * const Active = machine
     *   .designEmpty("Active")
     *   .command("deactivate", [Deactivate], () => [Deactivate.make()])
     *   .finish();
     *
     * // this function accepts a typed state instance of Active
     * const deactivate = (state: StateOf<Active>) => {
     *   if (SOME_THRESHOLD()) {
     *     state.commands()?.deactivate()
     *   }
     * }
     *
     * // calling the function
     * machine.get()?.as(Active, (state) => deactivate(state));
     */
    type Of<T extends StateFactory.Any> = T extends StateFactory<any, any, any, infer StateName, infer StatePayload, infer Commands> ? State<StateName, StatePayload, Commands> : never;
}
export {};
